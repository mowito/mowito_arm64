// Auto-generated. Do not edit!

// (in-package mw_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class CostGrid {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.cost_grid = null;
    }
    else {
      if (initObj.hasOwnProperty('cost_grid')) {
        this.cost_grid = initObj.cost_grid
      }
      else {
        this.cost_grid = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type CostGrid
    // Serialize message field [cost_grid]
    bufferOffset = _arraySerializer.uint8(obj.cost_grid, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type CostGrid
    let len;
    let data = new CostGrid(null);
    // Deserialize message field [cost_grid]
    data.cost_grid = _arrayDeserializer.uint8(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.cost_grid.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mw_msgs/CostGrid';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'ce472b499aac62b5378bd9d59677fcbc';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint8[] cost_grid
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new CostGrid(null);
    if (msg.cost_grid !== undefined) {
      resolved.cost_grid = msg.cost_grid;
    }
    else {
      resolved.cost_grid = []
    }

    return resolved;
    }
};

module.exports = CostGrid;
