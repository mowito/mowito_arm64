#include <mw_maxl_planner/mw_maxl_planner_ros1.h>

/**
 *
 * @file mw_maxl_dol.h
 * @brief DOL Class (Safe Teleop Mode)
 * @author Shankrith S <shankrith1618@gmail.com>
 *
 */

namespace mw_maxl_planner {

    class DOL
    {

    public:
        /**
         * @brief Construct a new DOL object
         */
        DOL(double &goalXYTolerance); 

        /**
         * @brief Destroy the DOL object
         */
        ~DOL(); 

        /**
         * @brief The helper function that checks if two poses are very close. 
         * @param pose_1 
         * @param pose_2
         * @returns true if poses are apart determined by POS_EPS, false otherwise.
         */
        // bool differentPose(const geometry_msgs::PoseStamped& pose_1, const geometry_msgs::PoseStamped& pose_2);

        /**
         * @brief The function to compute velocity command using maxl
         * @param cmd_vel variable to be set with calculated velocity by maxl 
         */
        void computeVelocity(geometry_msgs::TwistStamped& cmd_vel);

        /**
         * @brief The callback function for incoming goal poses.
         * @param goal contains a stamped pose in robot frame. 
         */
        void goalCB(const geometry_msgs::PoseStamped::ConstPtr& goal);

        /**
         * @brief Checks if robot has reached set goal.
         * @returns true if robot has reached goal, false otherwise.
         */
        bool isGoalReached();

        /**
         * @brief Checks if DOL class has recieved first goal.
         * @returns true if first goal has been recieved, false otherwise.
         */
        bool isFirstGoalRecieved();

    private: 
        // const double POS_EPS = 0.001;
        geometry_msgs::PoseStamped previous_goal_;
        boost::shared_ptr<tf2_ros::Buffer> tf2Buf_;
        double goalXYTolerance_ = 0;

        // tf::TransformListener listener_;
        // std::string map_frame_, robot_frame_;

        bool first_goal_recieved_ = false;

        boost::shared_ptr<mw_maxl_planner::MwMaxlPlanner> mw_maxl_ptr_;
    };
}