/**
 *
 * @file maxl_planner.h
 * @brief The MaxL Planner class.
 * @author Puru Rastogi <puru@mowito.in>
 *
 */

#ifndef MAXL_PLANNER_H
#define MAXL_PLANNER_H

// C++ classes
#include <math.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>

// Mowito Nav Stack base class
// #include <controller_executive/base_controller.h>

// PCL header
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/kdtree/kdtree_flann.h>

#include <pcl_ros/point_cloud.h>
#include <pcl_ros/transforms.h>

#include <mw_maxl_planner/mw_pure_pursuit.h>
#include <mw_maxl_planner/mw_maxl_planner_structs.h>
#include <mw_maxl_planner/mw_maxl_planner_scoring.h>
// #define M_PI 3.1415926
#include <mw_maxl_planner/mw_maxl_logger.h>
#include <mw_maxl_planner/mw_maxl_planner_oscillation.h>

#include <fstream>
#include <iostream>

namespace mw_maxl_planner
{

  /**
    * @class MaxlPlanner
    * @brief Implements both controller::AbstractController
    */
  class MaxlPlanner
  {
    public:
      /**
        * @brief Default constructor of the teb plugin
        */
      MaxlPlanner(maxlRobotConfigParams robotConfig,
                  maxlSpeedAccel speedAccel,
                  maxlTuningParams tuningParams,
                  maxlInflationParams inflationParams,
                  maxlFrames frames,
                  maxlRobotFootprintParams robotFootprint,
                  maxlObstacleRanges obstacleRanges,
                  PurePursuitParam purePursuitParams,
                  maxlMiscellaneousParams miscellaneousParams,
                  maxlOscPathIndex oscPathIndex,
                  maxlOscAngVel oscAngVel,
                  maxlScoringParams scoringParams,
                  maxlControllerParams controllerParams,
                  maxlPathParams pathParams,
                  maxlVelocityParams velocityParams);

      /**
        * @brief  Destructor of the plugin
        */
      ~MaxlPlanner();

    public:
#ifdef ROS2
      rclcpp::Logger logger_ {rclcpp::get_logger("maxl_planner")}; //https://answers.ros.org/question/355985/global-logger-for-logging-without-a-node/
#endif
      // callbacks for subscriber mentioned in maxl_planner_mw
      void odometryHandler(const mw_maxl_planner::Pose2dStamped &odom_pose_out, double vehicleSpeed, double vehicleYawRate);
      void velodynScanHandler(const pcl::PointCloud<pcl::PointXYZI>::Ptr& laserCloud);
      void laserScanHandler(const pcl::PointCloud<pcl::PointXYZI>::Ptr& laserCloud);
      void globalPathHandler(const mw_maxl_planner::Path& path);
      bool computePath();
      void clearPlan();
      void computeVelocity();
      void getCmdVel(mw_maxl_planner::TwistStamped &cmd_vel);
      bool isGoalReached(double dist_tolerance, double angle_tolerance);
      void libreconfigure(mw_maxl_planner::MaxlReconfigure &config);
      // sets goalX_ and goalY_
      void setGoal(const double& goal_x, const double& goal_y);
      // sets goalX_ and goalY_ for path tracker mode by calculating lookahead with getLookAheadgoal()
      void calcAndSetLookaheadGoal();
      // gets local path
      mw_maxl_planner::Path getLocalPath();
      // gets relative goal
      mw_maxl_planner::PointStamped getRelativeGoal();
      // gets uniform density plan
      mw_maxl_planner::Path getUniformDensityPlan();
      // gets lookahead goal
      mw_maxl_planner::PointStamped getLookaheadGoal();
      // gets cropped scan
      pcl::PointCloud<pcl::PointXYZI>::Ptr getCroppedScan();
      // gets inflated scan
      pcl::PointCloud<pcl::PointXYZI> getInflatedScan();
      // gets free paths
      pcl::PointCloud<pcl::PointXYZI>::Ptr getFreePaths();
      // gets blocked paths
      pcl::PointCloud<pcl::PointXYZI>::Ptr getBlockedPaths();
      //set relative goal directly using this function
      void setRelativeGoal(const mw_maxl_planner::Pose2d &goal);
      //make global plan uniform density
      mw_maxl_planner::Path makeGlobalPlanUniformDensity(const mw_maxl_planner::Path &plan);
      // for passing path folder
      void PassPathFolder(std::string PathFolder);
      // Set robot config
      void setRobotConfig(const maxlRobotConfigParams &robotConfig);
      // Set speed and acceleration
      void setSpeedAccel(const maxlSpeedAccel &speedAccel);
      // Set tuning params
      void setTuningParams(const maxlTuningParams &tuningParams);
      // Set inflation params
      void setInflationParams(const maxlInflationParams &inflationParams);
      // Set robot frames
      void setFrames(const maxlFrames &frames);
      // Set robot footprint
      void setRobotFootprint(const maxlRobotFootprintParams &robotFootprint);
      // Set obstacle ranges
      void setObstacleRanges(const maxlObstacleRanges &obstacleRanges);
      // Set miscellaneous params
      void setMiscellaneousParams(const maxlMiscellaneousParams &miscellaneousParams);
      // Set oscillation path index
      //void setOscPathIndex(const maxlOscPathIndex &oscPathIndex);
      // Set oscillation angular velocity
      //void setOscAngVel(const maxlOscAngVel &oscAngVel);
      // Set scoring params
      void setScoringParams(const maxlScoringParams &scoringParams);
      // Set controller params
      void setControllerParams(const maxlControllerParams &controllerParams);
      // Set path params
      void setPathParams(const maxlPathParams &pathParams);
      // Set velocity params
      void setVelocityParams(const maxlVelocityParams &velocityParams);

    protected:
      /**
        * @brief  Reads the header of the motion primitives
        */
      void readHeader(FILE *filePtr,  int arr[]);
      /**
        * @brief  Reads the motion primitives
        */
      void readPathFile();
      void readCorrespondences();

    private:
      std::string pathFolder_;
      std::string pathFile_ = "/paths"; //default
      std::string map_frame_;
      std::string robot_frame_;
      std::string velodyne_frame_;

      // Robot param variables
      double vehicleLength_ = 0.22;
      double vehicleWidth_ = 0.22;
      double sensorOffsetX_ = 0; //unused
      double sensorOffsetY_ = 0; //unused

      double adjacentRange_;

      double dirWeight_;
      double dirThre_;//90.0;

      double pathScale_ = 1.0;
      double minPathScale_ = 0.75;
      double pathScaleStep_ = 0.25;

      double minPathRange_ = 1.0;

      double goalX_,goalY_;

      //parameters for accurate rotation
      bool withinHighAccuracy_ = false;
      double highAccuracyMultiplier_;

      //parameters for controlling scoring behaviour
      double inPlaceRotationPenaltyFactor_ = 0.05; // higher value means in place rotation is penalised more
      double goalDirectionPreferenceFactor_ = 0.05; //higher value means paths oriented towards the goal are preferred

      // parameters for obstacle inflation
      double xInflate_ = 0.16; //inflate +- xInflate_ / 2 meters in path frame
      double yInflate_ = 0.80; //inflate +- yInflate_ / 2 meters in path frame


      const int laserCloudStackNum = 1;
      int laserCloudCount = 0;

      double joySpeed = 0;
      double joyDir = 0;

      double smoothVel=0.0;
      const int velWindowSize = 3;
      std::deque<double> velHistory; //odom vel data collection queue

      //default values
      int pathNum = 27;//343;
      int groupNum = 3;//7;
      // int pathpoints;
      double searchRadius;

      const int gridVoxelNumX = 161;
      const int gridVoxelNumY = 451;
      const int gridVoxelNum = gridVoxelNumX * gridVoxelNumY;

      pcl::PointCloud<pcl::PointXYZI>::Ptr laserCloudCrop = pcl::PointCloud<pcl::PointXYZI>::Ptr(new pcl::PointCloud<pcl::PointXYZI>());
      pcl::PointCloud<pcl::PointXYZI>::Ptr laserCloudDwz = pcl::PointCloud<pcl::PointXYZI>::Ptr(new pcl::PointCloud<pcl::PointXYZI>());
      pcl::PointCloud<pcl::PointXYZI>::Ptr freePaths = pcl::PointCloud<pcl::PointXYZI>::Ptr(new pcl::PointCloud<pcl::PointXYZI>());
      pcl::PointCloud<pcl::PointXYZI>::Ptr blockedPaths {new pcl::PointCloud<pcl::PointXYZI>()};
      pcl::PointCloud<pcl::PointXYZI>::Ptr plannerCloudCrop = pcl::PointCloud<pcl::PointXYZI>::Ptr(new pcl::PointCloud<pcl::PointXYZI>());
      pcl::PointCloud<pcl::PointXYZI> inflatedLaser;
      int laserCloudSize_; //to check if the laser scan topic has any points. This is a good way to check if the scan topic is correct

      std::vector<pcl::PointCloud<pcl::PointXYZI>::Ptr> laserCloudStack = std::vector<pcl::PointCloud<pcl::PointXYZI>::Ptr>(laserCloudStackNum);
      std::vector<pcl::PointCloud<pcl::PointXYZ>::Ptr> startPaths = std::vector<pcl::PointCloud<pcl::PointXYZ>::Ptr> (groupNum);
      std::vector<pcl::PointCloud<pcl::PointXYZI>::Ptr> paths = std::vector<pcl::PointCloud<pcl::PointXYZI>::Ptr> (pathNum);

      std::vector<int>   pathList = std::vector<int>(pathNum, 0);
      std::vector<double> endDirPathList = std::vector<double>(pathNum, 0);
      std::vector<double> endDirYawList = std::vector<double>(pathNum, 0);
      std::vector<std::vector<int>> correspondences = std::vector<std::vector<int>>(gridVoxelNum); //= std::vector<int>(gridVoxelNum);

      bool newLaserCloud = false;

      double odomTime;

      double vehicleYaw;
      double vehicleX, vehicleY, vehicleZ;

      double vehicleXRec, vehicleYRec, vehicleYawRec;
      int pathPointID = 0;

      pcl::VoxelGrid<pcl::PointXYZI> laserDwzFilter;

      mw_maxl_planner::Path global_path_;

      mw_maxl_planner::Pose2d current_pose_;

      mw_maxl_planner::Path path_;

      // for controller
      double lookAheadDis_ = 0.5;

      double maxSpeed_ = 0.4;
      double maxAccel_ = 0.5;
      double vehicleYawRate = 0;
      double vehicleSpeed = 0;

      //yaw gains are multiplied with the direction difference to obtain yaw rate
      //yaw gain used when robot is in motion (velocity above a certain threshold)
      double yawRateGain_ = 2.5; //3.5
      //yaw gain used when robot is stopped/almost stopped (velocity below the threshold)
      double stopYawRateGain_ = 0.6; //3.5
      //maximum yaw rate for the robot
      double maxYawRate_ = 0.5;

      bool navFwd = true;
      double switchTime = 0;

      //for enabling visualisation of croppedScan, inflatedScan, and freePaths Point Cloud data
      bool visPointCloud_;

      mw_maxl_planner::TwistStamped cmd_vel;

      // to take velocity from odom messages
      bool use_odom_velocity_;
      // to enable reverse mode
      bool reverse_enabled_;
      // vehicle speed and yaw rate from odometry
      double odometry_vehicleSpeed, odometry_vehicleYawRate;

      // shared pointer to pure pursuit object
      boost::shared_ptr<mw_maxl_planner::PurePursuit> pure_pursuit_;

      mw_maxl_planner::PointStamped relativeGoal_, lookahead_goal_;

      //compute path variables
      double gridVoxelSize;
      double gridVoxelOffsetX;
      double gridVoxelOffsetY;
      bool pathCrop_;
      double pathRangeStep_;
      double lowerBoundZ_;
      double upperBoundZ_;
      int pointPerPathThre_;
      double costScore_;
      double speedToRangeScale_;
      double obstacleHeightThre_;
      double groundHeightThre_;
      double costHeightThre_;
      bool checkObstacle_;
      bool checkRotObstacle_;
      double yawGainFactor_;

      // compute velocity variables
      double slowDwnDisThre;
      double spot_turn_thre_;
      double switchTimeThre;
      double speedLimDeno;

      bool rel_motion_mode_;
      double relativeGoalX_;
      double relativeGoalY_;
      double relativeGoalYaw_;

      //uniform density plan
      mw_maxl_planner::Path uniformDensityPlan_;
      double uniform_global_plan_threshold_;

      //chose scoring algo index
      int scoring_algo_index_;

      //objects for obtaining scoring params and path scoring functions
      mw_maxl_planner::MaxlScoringParams scoring_params_;
      boost::shared_ptr<mw_maxl_planner::MaxlPlannerScoring> mw_maxl_scoring_;

      boost::shared_ptr<mw_maxl_planner_oscillation::MaxlPlannerOscillation> mw_maxl_oscillation_;

      //scoring algo
      int scoring_algo_four_senstivity_factor_;

      int truncated_fan_angle_; //max angle on each side of the goal maxl will use to score paths
      bool truncate_fan_; //if true, fan will be truncated
  };

} // end namespace maxl_planner

#endif // MAXL_PLANNER_H_
