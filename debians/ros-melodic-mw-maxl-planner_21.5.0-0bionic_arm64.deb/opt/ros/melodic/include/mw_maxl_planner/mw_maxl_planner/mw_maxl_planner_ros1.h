
#ifndef MW_MAXL_PLANNER_H_
#define MW_MAXL_PLANNER_H_

// uncomment the line below, if you want to use the ROS loggers
// #define ROS
#include <ros/ros.h>
// C++ Headers
#include <string.h>
// ROS Message
#include <std_msgs/Bool.h>
#include <std_msgs/Float32.h>
#include <nav_msgs/Path.h>
#include <nav_msgs/Odometry.h>
#include <nav_msgs/Path.h>
#include <geometry_msgs/Pose2D.h>
#include <geometry_msgs/PointStamped.h>
#include <geometry_msgs/PolygonStamped.h>
#include <sensor_msgs/Imu.h>
#include <sensor_msgs/PointCloud2.h>
#include <sensor_msgs/Joy.h>
#include <sensor_msgs/LaserScan.h>
#include <geometry_msgs/Twist.h>

// dynamic reconfigure
#include <dynamic_reconfigure/server.h>
#include <mw_maxl_planner/MaxLPlannerConfig.h>

// Others
#include <laser_geometry/laser_geometry.h>
#include <message_filters/subscriber.h>
#include <message_filters/synchronizer.h>
#include <message_filters/sync_policies/approximate_time.h>
//service header
#include <mw_msgs/ChangeMprims.h>

// ROS Headers
#include <dynamic_reconfigure/server.h>
#include <mw_maxl_planner/mw_maxl_planner.h>

#include <controller_executive/base_controller.h>

#include <mlicense/license.hpp>
namespace mw_maxl_planner {
/**
 * @class MaxlPlannerROS
 * @brief A ROS wrapper for the trajectory controller that queries the param server to construct a controller
 */
class MwMaxlPlanner : public controller::AbstractController {
 public:
  /**
   * @brief  Default constructor for the ros wrapper
   */
  MwMaxlPlanner();

  /**
   * @brief  Constructs the ros wrapper
   * @param name The name to give this instance of the trajectory planner
   * @param tf A pointer to a transform listener
   * @param costmap The cost map to use for assigning costs to trajectories
   */
  void initialize(const std::string &name, const TFPtr &tf_listener_ptr);
  void reconfigureCB(mw_maxl_planner::MaxLPlannerConfig &config, uint32_t level);
  void odometryHandler(const nav_msgs::Odometry::ConstPtr& odom);
  void velodynScanHandler(const sensor_msgs::PointCloud2::ConstPtr& scanIn);
  void laserScanHandler(const sensor_msgs::LaserScan::ConstPtr& scanIn);

  /**
   * @brief Function to read the pathNum and groupNum from the header of the paths_and_groups file
   */
  void readPathGroupNum();

  /**
   * @brief  Destructor for the wrapper
   */
  ~MwMaxlPlanner();

  // ###################################
  // #  Abstract Controller Functions  #
  // ###################################

  unsigned int computeVelocityCommands(const geometry_msgs::PoseStamped &pose,
                                       const geometry_msgs::TwistStamped &velocity,
                                       geometry_msgs::TwistStamped &cmd_vel,
                                       std::string &message) override;

  /**
   * @brief Check if the goal pose has been achieved by the local planner
   * @param angle_tolerance The angle tolerance in which the current pose will be partly accepted as reached goal
   * @param dist_tolerance The distance tolerance in which the current pose will be partly accepted as reached goal
   * @return True if achieved, false otherwise
   */
  bool isGoalReached(double dist_tolerance, double angle_tolerance) override;

  /**
   * @brief Set the plan that the local planner is following
   * @param plan The plan to pass to the local planner
   * @return True if the plan was updated successfully, false otherwise
   */
  bool setPlan(const std::vector<geometry_msgs::PoseStamped> &plan) override;

  /**
   * @brief Requests the planner to cancel, e.g. if it takes too much time.
   * @return True if a cancel has been successfully requested, false if not implemented.
   */
  bool cancel() override;

  void reset() override;
  //function callback of service to change mprims responce mention by "res" is redundant right now
  bool changeMprims(mw_msgs::ChangeMprims::Request  &req, mw_msgs::ChangeMprims::Response &res);


  /**
   * @brief Compute velocity commands for dol mode
   * @param cmd_vel velocity for the robot
   * @return 0 if success, else 0
   */
  unsigned int computeVelocityForGoal(geometry_msgs::TwistStamped &cmd_vel);

  // ##################################
  // #  Trajectory Planner Functions  #
  // ##################################

  /**
   * @brief publishes the local path
   */
  void publishLocalPath();

  /**
   * @brief publishes the free paths
   */
  void publishFreePaths();

  /**
   * @brief publishes the filtered plan
   */
  void publishFilteredPlan();

  /**
   * @brief publishes the blocked paths
   */
  void publishBlockedPaths();

  /**
   * @brief publishes the inflated laser scan
   */
  void publishInflatedLaserScan();

  /**
   * @brief publishes the final transformed laser scan used by the maxl for computation.
   *        could be used for debugging.
   */
  void publishInputLaserScan();
  /**
   * @brief publishes cropped laser scan from maxl.
   */
  void publishCroppedLaserScan();

  /**
   * @brief used to stop robot i.e. give it zero velocity continously through computeVelocityCommands functio to stop robot
   * @return returns msg of type TwistStamped with each parameter set to zero
   */
  geometry_msgs::TwistStamped getZeroCmdVel();

  bool isInitialized() {
    return initialized_;
  }

  //void setGoal(const double& goal_x, const double& goal_y);
  void setGoal(const geometry_msgs::PoseStamped& goal);

  //set relative goal directly using this function
  void setRelativeGoal(const geometry_msgs::PoseStamped& goal);

  /** @brief Return the inner TrajectoryPlanner object.  Only valid after initialize().
  TrajectoryPlanner *getPlanner() const {
    return tc_;
  }
  */

  /***************************** CONVERTER FUNCTIONS ******************************************************************************/
  void rosPoseStampedTomaxlPose2dStamped(const geometry_msgs::PoseStamped &robot_pose, mw_maxl_planner::Pose2dStamped &maxl_pose);
  void rosPoseStampedTomaxlPose2d(const geometry_msgs::PoseStamped &pose_in, mw_maxl_planner::Pose2d &pose_out);

  void maxlPose2dTorosPoseStamped(const mw_maxl_planner::Pose2d &pose_in, geometry_msgs::PoseStamped &pose_out);

  void maxlPointStampedTorosPointStamped(const mw_maxl_planner::PointStamped &pose_in, geometry_msgs::PointStamped &pose_out);
  void rosPointStampedTomaxlPointStamped(const geometry_msgs::PointStamped &pose_in, mw_maxl_planner::PointStamped &pose_out);

  void maxlTwistStampedTorosTwistStamped(const mw_maxl_planner::TwistStamped &pose_in, geometry_msgs::TwistStamped &pose_out);

  void maxlPathTorosPath(const mw_maxl_planner::Path &path_in, nav_msgs::Path &path_out);
  /* ****************************************************************************************************************************** */
 private:
  /**
   * @brief Callback to update the local planner's parameters based on dynamic reconfigure
   */
  // void reconfigureCB(controller_executive::TrajectoryPlannerConfig &config, uint32_t level);

  bool initialized_ = false;
  bool reached_goal_;
  // shared pointer for maxl planner
  boost::shared_ptr<mw_maxl_planner::MaxlPlanner> maxl_planner_;
  dynamic_reconfigure::Server<mw_maxl_planner::MaxLPlannerConfig> *dsrv_;
  mw_maxl_planner::MaxLPlannerConfig default_config_;
  // Publisher and subscriber
  ros::Subscriber subScan_, subOdometry_; //, subGlobalPath;
  ros::Publisher pubPath_, pubLookaheadGoal_, pubScan_, pubFreePaths_, pubRelativeGoal_, pubCroppedScan_, pubInflatedScan_, pubBlockedPaths_,pubFilteredPlan_;
  //service for changing motion primitives at real time
  ros::ServiceServer mprims_server;

  bool use_laser_;
  bool plot_path_;  // unused
  bool mprims_changed_ = true;
  std::string odomTopic_;
  std::string velodyneTopic_;
  std::string scanTopic_;
  std::string mobileGoalTopic_; // unused

  std::string pathFolder_;
  std::string pathFile_ = "/paths";
  std::string map_frame_;
  std::string robot_frame_;
  std::string velodyne_frame_;

  //no of paths and groups generated by the mprims
  int pathNum_;
  int groupNum_;

  //for enabling visualisation of croppedScan, inflatedScan, and freePaths PointCloud data
  bool vis_pointcloud_;

  double odomTime_;

  tf::TransformListener listener_;

  pcl::PointCloud<pcl::PointXYZI>::Ptr scanData_ = pcl::PointCloud<pcl::PointXYZI>::Ptr(new pcl::PointCloud<pcl::PointXYZI>());
  pcl::PointCloud<pcl::PointXYZI>::Ptr laserCloud_ = pcl::PointCloud<pcl::PointXYZI>::Ptr(new pcl::PointCloud<pcl::PointXYZI>());
  pcl::PointCloud<pcl::PointXYZI>::Ptr plannerCloudCrop_ = pcl::PointCloud<pcl::PointXYZI>::Ptr(new pcl::PointCloud<pcl::PointXYZI>());
};
}
#endif
