/**
 *
 * @file maxl_planner_scoring.h
 * @brief The MaxL Planner scoring class.
 * @author Ankur Bodhe <ankur@mowito.in>
 *
 */

#ifndef MAXL_PLANNER_SCORING_H
#define MAXL_PLANNER_SCORING_H

// C++ classes
#include <math.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <mw_maxl_planner/mw_maxl_planner_structs.h>
#include <mw_maxl_planner/mw_maxl_logger.h>


namespace mw_maxl_planner
{
    /**
     * @class MaxlPlannerScoring
     * @brief Implements a class with different path scoring functions
    */
   class MaxlPlannerScoring
   {
        private:
            /**************** Params for scorePathsFour ******************************/
            bool done_handling_oscillation_; //a temporary flag to handle oscillation. It be false when oscillations are to be handled.
                                            // and will get true only when oscillation detection algo is done
            double test_dir_pref_; //a temporary value of goal_direction_preference_ to handle oscillation
            double test_in_place_; //a temporary value of in_place_rotation_penalty_ to handle oscillation
            int senstivity_factor_;// this factor if increased will increase the time of oscillation handling and will make the algo implement
                                   // a vigirous range of values to the scoring algo. Increase the value if the robot is stuck for longer at a place
            const double DEFT_INC_FOR_INRP_ = 0.01; //default value for increment of in_place_rotation_penalty_. Does not change
            const double DEFT_INIT_FOR_TEST_DIR_PREF_ = 0.0001; //default value of test_dir_pref_. test_dir_pref_ changes but gets set to this value again after
                                                 // oscillations are handeled.
            const int DEFT_SENS_BASE_ = 5; //default base value over which senstivity_factor_ is put as an exponent
            const int TEST_IN_PLACE_LIMIT_FAC_ = 4; //this sets the upper limit of test_in_place_ when handling oscillations
            /**********************************************************************/

            mw_maxl_planner::MaxlScoringParams params_for_scoring_;

        public:
            /**
             * @brief : Consturctor that set the scoring_index variable. Default value = 1
             *
            **/
            MaxlPlannerScoring();

            /**
             * @brief : Function that set the scoring index based on the given input
             * @param : scoring function index
             *
            **/
            void setScoringParams(mw_maxl_planner::MaxlScoringParams &score_params);

            /**
             * @brief  : Function to compute the path score by choosing the scoring function based on the scoring index provided
             * @param  : scoring function parameters
             * @return : Path score
            **/
            double scorePaths();

        private:
            /**
             * @brief  : Function to compute the path score based on the following heuristic
             *           1. as dirDiff_pathDir gets closer to 0, robot faces lookahead goal, score increases.
             *           2. rotDirW is an integer in range [1, 19]. rotDir = 18 corresponds to straight path and rotDirW of 19.
             *           3. thus as rotDir becomes farther from 18, robot must rotate, which reduces rotDirW, which reduces score.
             * @param  : inPlaceRotationPenaltyFactor (default = 0.05) , goalDirectionPreferenceFactor (default = 0.2), dirDiff_pathDir, rotDir
             * @return : Path score
            **/
            double scorePathsOne(double inPlaceRotationPenaltyFactor,
                                   double goalDirectionPreferenceFactor,
                                   double dirDiff_pathDir, int rotDir);

            /**
             * @brief  : Function to compute the path score based on the following heuristic
             *           1. most paths have a negative score, only a few have a positive score.
             *           2. we are sieving out all the negatives and only storing the positives.
             *           3. finding highest scoring group and start angle based on only the positive scores.
             * @param  : dirWeight,  costScore, dirDiff_pathDir, rotDir, penaltyScore
             * @return : Path score
            **/
            double scorePathsTwo(double dirWeight, double costScore,
                                   double dirDiff_pathDir, int rotDir, double penaltyScore);

            /**
             * @brief  : Function to compute the path score based on the following heuristic
             *           1. as dirDiff_pathDir gets closer to 0, robot faces lookahead goal, score increases.
             *           2. rotDirW is an integer in range [1, 19]. rotDir = 18 corresponds to straight path and rotDirW of 19
             *           3. thus as rotDir becomes farther from 18, robot must rotate, which reduces rotDirW, which reduces score if the goal is in front of the robot.
             *           4. the position of the goal w.r.t. the robot can be found by the help of joyDir, its value is from (-90, 90) if the goal is in front of the
             *           5. robot otherwise the goal is behind the robot. If behind we prefer the centre path index of fan of paths behind the robot i.e 0. Hence as
             *              rotDir goes away from 0 score reduces when the goal is behind the robot.
             * @param  : inPlaceRotationPenaltyFactor (default = 0.05),  goalDirectionPreferenceFactor (default = 0.2), dirDiff_pathDir, rotDir, joyDir
             * @return : Path score
            **/
            double scorePathsThree(double inPlaceRotationPenaltyFactor,
                                     double goalDirectionPreferenceFactor,
                                     double dirDiff_pathDir, int rotDir, double joyDir);

            double scorePathsFour(double dirDiff_pathDir, int rotDir, double joyDir,
                                    double inPlaceRotationPenaltyFactor, double goalDirectionPreferenceFactor,
                                    bool is_oscillating,double dirDiff_endYaw);

    

   };

}


#endif // MAXL_PLANNER_SCORING_H_
