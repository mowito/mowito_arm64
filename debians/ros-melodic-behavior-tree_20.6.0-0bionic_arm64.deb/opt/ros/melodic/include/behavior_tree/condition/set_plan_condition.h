/**
* @file set_plan_condition_action.h
* @author Divyanshu Sahu
* @brief Header file for setting a given plan via txt file. This file has similar elements to the set_route_condition.h and the set_waypoint_condition.h files
*/

//required header files
#ifndef SET_PLAN_CONIDTION
#define SET_PLAN_CONIDTION

#include "behaviortree_cpp_v3/behavior_tree.h"
#include "behaviortree_cpp_v3/bt_factory.h"
#include <mw_msgs/GetPathAction.h> 
#include <mw_msgs/ExePathAction.h>
#include <nav_msgs/Odometry.h>
#include <actionlib/client/simple_action_client.h>
#include "behaviortree_cpp_v3/bt_factory.h"
#include "behaviortree_cpp_v3/behavior_tree.h"
#include <ros/ros.h>
#include "geometry_msgs/Pose.h"
#include "geometry_msgs/PoseStamped.h"
#include <vector>
#include <executive/mission_executive.h>
#include <fstream>
#include <sstream>
#include <string>
#include <iostream>

using namespace BT;
using namespace std;

namespace bt_mowito
{

	class setplancondition : public ConditionNode
		{
  		public:
   			setplancondition(const std::string& condition_name, const NodeConfiguration& conf);

   			static BT::PortsList providedPorts() {return {OutputPort<nav_msgs::Path>("out_path"), InputPort<bool>("in_flag"), OutputPort<int>("start_bt_flag"),  OutputPort<bool>("out_flag")};}
	    		/*
	            * brief:The method for initialising the required input and output ports for the BLACKBOARD
	            * Input Port: the "in_flag" is used to know if the followpath_action is done or not 
	            * Output port: the "out_path" is used to set the required path on the BLACKBOARD. The "start_bt_flag" is to know if the robot has been in hybernation or not. 
	            * the "out_flag" is an initialsing port for the "in_flag". 
	            */
                  bool setCurrentPlan(mw_msgs::SetPlan::Request &req, mw_msgs::SetPlan::Response &resp);

                  bool abortMission(std_srvs::Empty::Request &req, std_srvs::Empty::Response &resp); 

   			BT::NodeStatus tick() override;

                  bool goal_reached();

   		private:

   	         	ros::NodeHandle n5;
                  ros::ServiceServer set_plan_; 
                  ros::ServiceServer abort_mission;    
                  ros::Publisher path_pub;
                  ros::Publisher goal_pub; 
                  ros::Publisher cmd_control;
                  geometry_msgs::Twist cmd_vel_zero_; 
                  bool service_call;
                  bool was_stuck;
                  int start_bt_flag;
                  int tick_count;
                  std::deque<nav_msgs::Path> path_queue;
            };

}
#endif   