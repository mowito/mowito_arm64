/**
* @file abortcontroller_action.h
* @author Divyanshu Sahu
* @brief Header file for invoking the abort controller service server
*/

//required header files
#ifndef ABORT_CONTROLLER_ACTION
#define ABORT_CONTROLLER_ACTION


#include <mw_msgs/GetPathAction.h> 
#include <mw_msgs/ExePathAction.h>
#include <actionlib/client/simple_action_client.h>
#include "behaviortree_cpp_v3/bt_factory.h"
#include "behaviortree_cpp_v3/behavior_tree.h"
#include <ros/ros.h>
#include "geometry_msgs/Pose.h"
#include "geometry_msgs/PoseStamped.h"
#include <geometry_msgs/Twist.h>
#include <vector>
#include <executive/mission_executive.h>
#include <fstream>
#include <sstream>
#include <string>
#include <iostream>

using namespace BT;
using namespace std;

// the bt_mowito namespace
namespace bt_mowito{

      //abortcontroller syncrohonous action class
	class abortcontroller : public SyncActionNode
	{
  		public:
    		
    		abortcontroller(const std::string& name, const NodeConfiguration& config);
            // If your Node has ports, you must use this constructor signature 
    		static PortsList providedPorts(){return{};}
            //we need no input or output ports for invoking the server.

    		BT::NodeStatus tick() override;

  		private:
  			ros::NodeHandle nh; //nodehandle
  			ros::ServiceClient client; // service client 
	};    										
}
#endif