
"use strict";

let GetCircumscribedRadius = require('./GetCircumscribedRadius.js')
let SetRoute = require('./SetRoute.js')
let GetTask = require('./GetTask.js')
let LoadTaskFromFile = require('./LoadTaskFromFile.js')
let GetRouteStatus = require('./GetRouteStatus.js')
let SetPlan = require('./SetPlan.js')
let GetPlan = require('./GetPlan.js')
let SetRobotFootprint = require('./SetRobotFootprint.js')
let SetMode = require('./SetMode.js')
let GetPose = require('./GetPose.js')
let LoadRouteFromFile = require('./LoadRouteFromFile.js')
let SetTask = require('./SetTask.js')
let GetTaskStatus = require('./GetTaskStatus.js')
let LoadDutyFromFile = require('./LoadDutyFromFile.js')
let SetNodeState = require('./SetNodeState.js')
let SetCost = require('./SetCost.js')
let GetString = require('./GetString.js')
let GetRoute = require('./GetRoute.js')
let SetString = require('./SetString.js')
let GetSbplPlan = require('./GetSbplPlan.js')
let SetDuty = require('./SetDuty.js')
let ComputeCircumscribedCost = require('./ComputeCircumscribedCost.js')
let GetDouble = require('./GetDouble.js')
let GetDuty = require('./GetDuty.js')

module.exports = {
  GetCircumscribedRadius: GetCircumscribedRadius,
  SetRoute: SetRoute,
  GetTask: GetTask,
  LoadTaskFromFile: LoadTaskFromFile,
  GetRouteStatus: GetRouteStatus,
  SetPlan: SetPlan,
  GetPlan: GetPlan,
  SetRobotFootprint: SetRobotFootprint,
  SetMode: SetMode,
  GetPose: GetPose,
  LoadRouteFromFile: LoadRouteFromFile,
  SetTask: SetTask,
  GetTaskStatus: GetTaskStatus,
  LoadDutyFromFile: LoadDutyFromFile,
  SetNodeState: SetNodeState,
  SetCost: SetCost,
  GetString: GetString,
  GetRoute: GetRoute,
  SetString: SetString,
  GetSbplPlan: GetSbplPlan,
  SetDuty: SetDuty,
  ComputeCircumscribedCost: ComputeCircumscribedCost,
  GetDouble: GetDouble,
  GetDuty: GetDuty,
};
