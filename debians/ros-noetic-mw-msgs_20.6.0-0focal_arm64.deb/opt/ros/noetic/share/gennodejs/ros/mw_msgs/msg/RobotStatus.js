// Auto-generated. Do not edit!

// (in-package mw_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class RobotStatus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.chief_executive_mode = null;
      this.battery_status = null;
      this.current_duty_id = null;
      this.current_task_id = null;
      this.task_type = null;
      this.error_code = null;
    }
    else {
      if (initObj.hasOwnProperty('chief_executive_mode')) {
        this.chief_executive_mode = initObj.chief_executive_mode
      }
      else {
        this.chief_executive_mode = 0;
      }
      if (initObj.hasOwnProperty('battery_status')) {
        this.battery_status = initObj.battery_status
      }
      else {
        this.battery_status = 0;
      }
      if (initObj.hasOwnProperty('current_duty_id')) {
        this.current_duty_id = initObj.current_duty_id
      }
      else {
        this.current_duty_id = 0;
      }
      if (initObj.hasOwnProperty('current_task_id')) {
        this.current_task_id = initObj.current_task_id
      }
      else {
        this.current_task_id = 0;
      }
      if (initObj.hasOwnProperty('task_type')) {
        this.task_type = initObj.task_type
      }
      else {
        this.task_type = 0;
      }
      if (initObj.hasOwnProperty('error_code')) {
        this.error_code = initObj.error_code
      }
      else {
        this.error_code = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RobotStatus
    // Serialize message field [chief_executive_mode]
    bufferOffset = _serializer.uint8(obj.chief_executive_mode, buffer, bufferOffset);
    // Serialize message field [battery_status]
    bufferOffset = _serializer.int32(obj.battery_status, buffer, bufferOffset);
    // Serialize message field [current_duty_id]
    bufferOffset = _serializer.uint32(obj.current_duty_id, buffer, bufferOffset);
    // Serialize message field [current_task_id]
    bufferOffset = _serializer.uint32(obj.current_task_id, buffer, bufferOffset);
    // Serialize message field [task_type]
    bufferOffset = _serializer.uint8(obj.task_type, buffer, bufferOffset);
    // Serialize message field [error_code]
    bufferOffset = _serializer.int32(obj.error_code, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RobotStatus
    let len;
    let data = new RobotStatus(null);
    // Deserialize message field [chief_executive_mode]
    data.chief_executive_mode = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [battery_status]
    data.battery_status = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [current_duty_id]
    data.current_duty_id = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [current_task_id]
    data.current_task_id = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [task_type]
    data.task_type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [error_code]
    data.error_code = _deserializer.int32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 18;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mw_msgs/RobotStatus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '699d693cf48a9114bc3b70b1cf34f11e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # robot status for UI
    
    # chief executive mode
    uint8 chief_executive_mode
    
    # 0 - 100
    int32 battery_status
    
    # 0 means no duty set / any positive integer represents a duty
    uint32 current_duty_id
    
    # if no duty set this is gibberish otherwise it represents the task id currently running
    uint32 current_task_id
    
    # if no duty set this is gibberish otherwise it represents type of current task 0 == route 1 == attachement task
    uint8 task_type
    
    # 0 == all is well any positive int means there is an issue for now just display the number
    int32 error_code
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RobotStatus(null);
    if (msg.chief_executive_mode !== undefined) {
      resolved.chief_executive_mode = msg.chief_executive_mode;
    }
    else {
      resolved.chief_executive_mode = 0
    }

    if (msg.battery_status !== undefined) {
      resolved.battery_status = msg.battery_status;
    }
    else {
      resolved.battery_status = 0
    }

    if (msg.current_duty_id !== undefined) {
      resolved.current_duty_id = msg.current_duty_id;
    }
    else {
      resolved.current_duty_id = 0
    }

    if (msg.current_task_id !== undefined) {
      resolved.current_task_id = msg.current_task_id;
    }
    else {
      resolved.current_task_id = 0
    }

    if (msg.task_type !== undefined) {
      resolved.task_type = msg.task_type;
    }
    else {
      resolved.task_type = 0
    }

    if (msg.error_code !== undefined) {
      resolved.error_code = msg.error_code;
    }
    else {
      resolved.error_code = 0
    }

    return resolved;
    }
};

module.exports = RobotStatus;
