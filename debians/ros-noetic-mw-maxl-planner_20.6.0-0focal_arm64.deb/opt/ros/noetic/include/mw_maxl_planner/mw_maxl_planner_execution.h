/**
 *
 * @file mw_maxl_planner_execution.h
 * @brief The Maximum Liklihood Planner executive class.
 * @author Puru Rastogi <puru@mowito.in>
 *
 */

#ifndef MW_MAXL_PLANNER_EXECUTION_H
#define MW_MAXL_PLANNER_EXECUTION_H

#include <controller_executive/base_controller_execution.h>

namespace mw_maxl_planner {

class MwMaxlPlannerExecution : public controller::AbstractControllerExecution {

 public:

  MwMaxlPlannerExecution();

  ~MwMaxlPlannerExecution();
};

}

#endif //MW_MAXL_PLANNER_EXECUTION_H