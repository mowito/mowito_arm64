#ifndef MAXL_PLANNER_STRUCTS_
#define MAXL_PLANNER_STRUCTS_

#include <vector>
#include <iostream>
#include <string.h>
#include <math.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
using namespace std;
namespace mw_maxl_planner
{
	struct Point
	{
		double x;
		double y;
		double z;
	};

	struct Pose2d
	{
		double x;
		double y;
		double z;
		double theta;  //range: [3.14, -3.14) 
	};

	struct Header
	{
		double time;
		std::string frame_id;
	};

	struct PointStamped
	{
		Point point;
		Header header;
	};

	struct TwistStamped
	{
		Point linear;
		Point angular;
		Header header;
	};

	struct Pose2dStamped
	{
		Pose2d pose;
		Header header;
	};

	struct Path
	{
		std::vector<Pose2d> poses;
		Header header; 
		
	};

	struct MaxlReconfigure
	{
		double min_lookahead;
		double max_lookahead;
		int closest_point_index_search;
	    double max_y_deviation;
	    double min_radius;
	    double max_radius;
	    double max_omega_radius;
	    double max_path_dev;
	    double lookahead_point_distance;
	    double lookahead_factor_val;
	    double lookahead_jump_threshold;
	   	double sensorOffsetX;
	    double sensorOffsetY;
	    double maxSpeed;
	    double maxAccel;
	    double highAccuracyMultiplier;
	    double yawRateGain;
	    double stopYawRateGain;
	    double maxYawRate; 
	   	double dirWeight;
	   	double dirThre;
	    double xInflate;
	    double yInflate;
	    double adjacentRange;
	    double minPathRange;
	    double visPointCloud;
	    double in_place_rotation_penalty;
	    double goal_direction_preference;
	    int scoring_algo_index;
	};
}

#endif // MAXL_PLANNER_STRUCTS_