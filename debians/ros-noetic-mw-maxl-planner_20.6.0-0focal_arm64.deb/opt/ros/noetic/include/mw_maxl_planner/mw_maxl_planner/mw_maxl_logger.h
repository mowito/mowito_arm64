/**
 *
 * @file maxl_logger.h
 * @brief to define logging for maxl library
 * @author Aswin Gururaj
 *
 */

#include <cstdio>
#define ROS
#ifdef ROS
	#include <ros/ros.h>
#endif

#ifndef __MAXL_LOGGER_H_
#define __MAXL_LOGGER_H_

/**
 * \brief different logging levels
 */
#define MAXL_LEVEL_DEBUG  0
#define MAXL_LEVEL_INFO   1
#define MAXL_LEVEL_WARN   2
#define MAXL_LEVEL_ERROR  3

typedef int (*MAXL_PRINT_TEXT_FP)(int level, const char*);

int MAXL_PRINTALL(int level, const char* format, ...);

/**
 * \brief Standard output logger macros
 */
#ifdef ROS
	#define MAXL_DEBUG                  ROS_DEBUG
	#define MAXL_INFO                   ROS_INFO
	#define MAXL_WARN                   ROS_WARN
	#define MAXL_ERROR                  ROS_ERROR
#else
	#define MAXL_DEBUG(...)             MAXL_PRINTALL(MAXL_LEVEL_DEBUG, __VA_ARGS__)
	#define MAXL_INFO(...)              MAXL_PRINTALL(MAXL_LEVEL_INFO, __VA_ARGS__)
	#define MAXL_WARN(...)              MAXL_PRINTALL(MAXL_LEVEL_WARN, __VA_ARGS__)
	#define MAXL_ERROR(...)             MAXL_PRINTALL(MAXL_LEVEL_ERROR, __VA_ARGS__)
#endif

#endif
