#ifndef COSTMAP_2D_TESTING_HELPER_H
#define COSTMAP_2D_TESTING_HELPER_H

#include<mw_costmap/cost_values.h>
#include<mw_costmap/costmap_2d.h>
#include <mw_costmap/static_layer.h>
#include <mw_costmap/obstacle_layer.h>
#include <mw_costmap/inflation_layer.h>

#include <sensor_msgs/point_cloud2_iterator.h>

const double MAX_Z(1.0);

void setValues(mw_costmap::Costmap2D& costmap, const unsigned char* map)
{
  int index = 0;
  for (int i = 0; i < costmap.getSizeInCellsY(); i++){
    for (int j = 0; j < costmap.getSizeInCellsX(); j++){
      costmap.setCost(j, i, map[index]);
    }
  }
}

char printableCost(unsigned char cost)
{
  switch (cost)
  {
  case mw_costmap::NO_INFORMATION: return '?';
  case mw_costmap::LETHAL_OBSTACLE: return 'L';
  case mw_costmap::INSCRIBED_INFLATED_OBSTACLE: return 'I';
  case mw_costmap::FREE_SPACE: return '.';
  default: return '0' + (unsigned char) (10 * cost / 255);
  }
}

void printMap(mw_costmap::Costmap2D& costmap)
{
  printf("map:\n");
  for (int i = 0; i < costmap.getSizeInCellsY(); i++){
    for (int j = 0; j < costmap.getSizeInCellsX(); j++){
      printf("%4d", int(costmap.getCost(j, i)));
    }
    printf("\n\n");
  }
}

unsigned int countValues(mw_costmap::Costmap2D& costmap, unsigned char value, bool equal = true)
{
  unsigned int count = 0;
  for (int i = 0; i < costmap.getSizeInCellsY(); i++){
    for (int j = 0; j < costmap.getSizeInCellsX(); j++){
      unsigned char c = costmap.getCost(j, i);
      if ((equal && c == value) || (!equal && c != value))
      {
        count+=1;
      }
    }
  }
  return count;
}

void addStaticLayer(mw_costmap::LayeredCostmap& layers, tf2_ros::Buffer& tf)
{
  mw_costmap::StaticLayer* slayer = new mw_costmap::StaticLayer();
  layers.addPlugin(boost::shared_ptr<mw_costmap::Layer>(slayer));
  slayer->initialize(&layers, "static", &tf);
}

mw_costmap::ObstacleLayer* addObstacleLayer(mw_costmap::LayeredCostmap& layers, tf2_ros::Buffer& tf)
{
  mw_costmap::ObstacleLayer* olayer = new mw_costmap::ObstacleLayer();
  olayer->initialize(&layers, "obstacles", &tf);
  layers.addPlugin(boost::shared_ptr<mw_costmap::Layer>(olayer));
  return olayer;
}

void addObservation(mw_costmap::ObstacleLayer* olayer, double x, double y, double z = 0.0,
                    double ox = 0.0, double oy = 0.0, double oz = MAX_Z){
  sensor_msgs::PointCloud2 cloud;
  sensor_msgs::PointCloud2Modifier modifier(cloud);
  modifier.setPointCloud2FieldsByString(1, "xyz");
  modifier.resize(1);
  sensor_msgs::PointCloud2Iterator<float> iter_x(cloud, "x");
  sensor_msgs::PointCloud2Iterator<float> iter_y(cloud, "y");
  sensor_msgs::PointCloud2Iterator<float> iter_z(cloud, "z");
  *iter_x = x;
  *iter_y = y;
  *iter_z = z;

  geometry_msgs::Point p;
  p.x = ox;
  p.y = oy;
  p.z = oz;

  mw_costmap::Observation obs(p, cloud, 100.0, 100.0);  // obstacle range = raytrace range = 100.0
  olayer->addStaticObservation(obs, true, true);
}

mw_costmap::InflationLayer* addInflationLayer(mw_costmap::LayeredCostmap& layers, tf2_ros::Buffer& tf)
{
  mw_costmap::InflationLayer* ilayer = new mw_costmap::InflationLayer();
  ilayer->initialize(&layers, "inflation", &tf);
  boost::shared_ptr<mw_costmap::Layer> ipointer(ilayer);
  layers.addPlugin(ipointer);
  return ilayer;
}


#endif  // mw_costmap_TESTING_HELPER_H
