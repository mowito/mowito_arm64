// Auto-generated. Do not edit!

// (in-package mw_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

let Task = require('../msg/Task.js');

//-----------------------------------------------------------

class GetTaskRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.id = null;
    }
    else {
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetTaskRequest
    // Serialize message field [id]
    bufferOffset = _serializer.uint32(obj.id, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetTaskRequest
    let len;
    let data = new GetTaskRequest(null);
    // Deserialize message field [id]
    data.id = _deserializer.uint32(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'mw_msgs/GetTaskRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '309d4b30834b338cced19e5622a97a03';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Default value 0 returns the current task
    uint32 id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetTaskRequest(null);
    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = 0
    }

    return resolved;
    }
};

class GetTaskResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.task = null;
    }
    else {
      if (initObj.hasOwnProperty('task')) {
        this.task = initObj.task
      }
      else {
        this.task = new Task();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetTaskResponse
    // Serialize message field [task]
    bufferOffset = Task.serialize(obj.task, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetTaskResponse
    let len;
    let data = new GetTaskResponse(null);
    // Deserialize message field [task]
    data.task = Task.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += Task.getMessageSize(object.task);
    return length;
  }

  static datatype() {
    // Returns string type for a service object
    return 'mw_msgs/GetTaskResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '0a68023e180ad7e553a9b38b008863ac';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    mw_msgs/Task task
    
    ================================================================================
    MSG: mw_msgs/Task
    # Unique ID for each task
    uint32 id
    
    # task_goal field when type is GTG
    mw_msgs/Route route
    geometry_msgs/Pose task_goal
    
    # Duration (in seconds) to run this task (when type is not ROUTE)
    float32 duration
    
    # End behaviour, ie, time to wait after this task ends and before starting the next task
    float32 end_behaviour
    
    # Enumeration for different types
    uint8 GTG=0
    uint8 WAIT=1
    
    # Type of task
    uint8 type
    
    
    # Enumeration for different task states
    uint8 NOT_STARTED=0
    uint8 WIP=1
    uint8 COMPLETED=2
    
    # Task status
    uint8 status
    
    
    ================================================================================
    MSG: mw_msgs/Route
    # Unique ID for each different route
    uint32 id
    
    # Header
    std_msgs/Header header
    
    # Array of waypoints
    geometry_msgs/PoseStamped[] waypoints
    
    # Route status
    uint8 status
    
    # Enumeration for different route states
    uint8 NOT_STARTED=0
    uint8 WIP=1
    uint8 COMPLETED=2
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/PoseStamped
    # A Pose with reference coordinate frame and timestamp
    Header header
    Pose pose
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetTaskResponse(null);
    if (msg.task !== undefined) {
      resolved.task = Task.Resolve(msg.task)
    }
    else {
      resolved.task = new Task()
    }

    return resolved;
    }
};

module.exports = {
  Request: GetTaskRequest,
  Response: GetTaskResponse,
  md5sum() { return '9264c79f3cce94355f72c36aa15cb8fe'; },
  datatype() { return 'mw_msgs/GetTask'; }
};
