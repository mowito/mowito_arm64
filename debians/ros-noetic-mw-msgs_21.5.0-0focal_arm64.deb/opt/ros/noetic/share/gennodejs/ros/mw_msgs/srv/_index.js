
"use strict";

let SetRoute = require('./SetRoute.js')
let GetTaskStatus = require('./GetTaskStatus.js')
let ChangeMprims = require('./ChangeMprims.js')
let SetString = require('./SetString.js')
let LoadTaskFromFile = require('./LoadTaskFromFile.js')
let GetDouble = require('./GetDouble.js')
let GetPose = require('./GetPose.js')
let SetCost = require('./SetCost.js')
let LoadRouteFromFile = require('./LoadRouteFromFile.js')
let SetMode = require('./SetMode.js')
let GetTask = require('./GetTask.js')
let SetManual = require('./SetManual.js')
let SetPlan = require('./SetPlan.js')
let RobotInfo = require('./RobotInfo.js')
let ComputeCircumscribedCost = require('./ComputeCircumscribedCost.js')
let FleetStatus = require('./FleetStatus.js')
let SetRobotFootprint = require('./SetRobotFootprint.js')
let LoadDutyFromFile = require('./LoadDutyFromFile.js')
let GetString = require('./GetString.js')
let GetCircumscribedRadius = require('./GetCircumscribedRadius.js')
let GetPlan = require('./GetPlan.js')
let GetSbplPlan = require('./GetSbplPlan.js')
let SetNodeState = require('./SetNodeState.js')
let GetRouteStatus = require('./GetRouteStatus.js')
let SetDuty = require('./SetDuty.js')
let GetDuty = require('./GetDuty.js')
let GetRoute = require('./GetRoute.js')
let SetTask = require('./SetTask.js')

module.exports = {
  SetRoute: SetRoute,
  GetTaskStatus: GetTaskStatus,
  ChangeMprims: ChangeMprims,
  SetString: SetString,
  LoadTaskFromFile: LoadTaskFromFile,
  GetDouble: GetDouble,
  GetPose: GetPose,
  SetCost: SetCost,
  LoadRouteFromFile: LoadRouteFromFile,
  SetMode: SetMode,
  GetTask: GetTask,
  SetManual: SetManual,
  SetPlan: SetPlan,
  RobotInfo: RobotInfo,
  ComputeCircumscribedCost: ComputeCircumscribedCost,
  FleetStatus: FleetStatus,
  SetRobotFootprint: SetRobotFootprint,
  LoadDutyFromFile: LoadDutyFromFile,
  GetString: GetString,
  GetCircumscribedRadius: GetCircumscribedRadius,
  GetPlan: GetPlan,
  GetSbplPlan: GetSbplPlan,
  SetNodeState: SetNodeState,
  GetRouteStatus: GetRouteStatus,
  SetDuty: SetDuty,
  GetDuty: GetDuty,
  GetRoute: GetRoute,
  SetTask: SetTask,
};
