/**
 *
 * @file maxl_logger.h
 * @brief to define logging for maxl library
 * @author Aswin Gururaj
 *
 */

#include <cstdio>
#ifdef ROS1
	#include <ros/ros.h>
#elif ROS2
    #include "rclcpp/rclcpp.hpp"
#endif

#ifndef __MAXL_LOGGER_H_
#define __MAXL_LOGGER_H_

/**
 * \brief different logging levels
 */
#define MAXL_LEVEL_DEBUG  0
#define MAXL_LEVEL_INFO   1
#define MAXL_LEVEL_WARN   2
#define MAXL_LEVEL_ERROR  3

typedef int (*MAXL_PRINT_TEXT_FP)(int level, const char*);

int MAXL_PRINTALL(int level, const char* format, ...);

/**
 * \brief Standard output logger macros
 */
#ifdef ROS1
	#define MAXL_DEBUG                  ROS_DEBUG
	#define MAXL_INFO                   ROS_INFO
	#define MAXL_WARN                   ROS_WARN
	#define MAXL_ERROR                  ROS_ERROR
	#define MAXL_INFO_THROTTLE			ROS_INFO_THROTTLE
	#define MAXL_WARN_THROTTLE			ROS_WARN_THROTTLE
#elif ROS2
    #define MAXL_DEBUG(...)                  RCLCPP_DEBUG(logger_, __VA_ARGS__)
	#define MAXL_INFO(...)                   RCLCPP_INFO(logger_, __VA_ARGS__)
	#define MAXL_WARN(...)                   RCLCPP_WARN(logger_, __VA_ARGS__)
	#define MAXL_ERROR(...)                  RCLCPP_ERROR(logger_, __VA_ARGS__)
    #define MAXL_INFO_THROTTLE(...)			 RCLCPP_INFO_THROTTLE(logger_, __VA_ARGS__)
	#define MAXL_WARN_THROTTLE(...) 		 RCLCPP_WARN_THROTTLE(logger_, __VA_ARGS__)
#else
	#define MAXL_DEBUG(...)             MAXL_PRINTALL(MAXL_LEVEL_DEBUG, __VA_ARGS__)
	#define MAXL_INFO(...)              MAXL_PRINTALL(MAXL_LEVEL_INFO, __VA_ARGS__)
	#define MAXL_WARN(...)              MAXL_PRINTALL(MAXL_LEVEL_WARN, __VA_ARGS__)
	#define MAXL_ERROR(...)             MAXL_PRINTALL(MAXL_LEVEL_ERROR, __VA_ARGS__)
#endif

#endif
