/**
 *
 * @file mw_maxl_planner_oscillation.h
 * @brief The MaxL Planner scoring class.
 * @author Divyanshu Sahu <divyanshu.research@gmail.com>
 *
 */

#ifndef MAXL_PLANNER_OSCILLATION_H
#define MAXL_PLANNER_OSCILLATION_H

// C++ classes
#include <math.h>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <mw_maxl_planner/mw_maxl_planner_structs.h>
#include <mw_maxl_planner/mw_maxl_logger.h>
#include <chrono>

namespace mw_maxl_planner_oscillation
{
	class MaxlPlannerOscillation
	{

		public:

			MaxlPlannerOscillation();

			void setOscillationParams(const mw_maxl_planner::maxlOscPathIndex &oscPathIndex, const mw_maxl_planner::maxlOscAngVel &oscAngVel);

			bool isOscillating();

			void checkOscillationUsingPathIndex(int chosen_path_index);

      void checkOscillationUsingAngularVelocity(mw_maxl_planner::TwistStamped cmd_vel);

    private:

      bool pi_chosen_flag_ = false;
      int pi_chosen_path_index_, pi_old_chosen_path_index_;
      double pi_osc_senstivity_= 5.0; //to control the senstivity of oscillation detection. If this value is high, even small jump in chosen path will 
                                              //be considered an oscillation
      int pi_osc_threshold_= 10; //Everytime an oscillation is detected, a count is increased. If this count goes 
                                         //above this threshold, oscillations are considered true and not just an error in detection
      int pi_osc_count_;
      int pi_osc_cooldown_; //if the oscillations detected are false (less than the oscillation_threshold), this param will reset everything
      bool osc_det_by_path_index_ = false; //if true, oscillations will be detected by checking jumps in path scoring algo

      double av_old_angular_vel_, av_new_angular_vel_; //to collect angular velocity values so we can compare them
      double av_ang_vel_oscillation_count_;// everytime the angular velocity direction changes, this count is increased 
      bool av_first_ang_vel_ = false; //to collect the first angular velocity value
      std::chrono::system_clock::time_point  av_initial_time_;//access system clock to keep a track of time
      double av_osc_sample_window_ = 1.0; //time period/window over which frequency of oscillation is calculated
      double av_osc_freq_threshold_ = 3.5; 

      //if the frequency of change in oscillation magnitude per av_osc_sample_window_ is more than this value, it is considered an oscillation
      bool osc_det_by_angular_velocity_ = true; //if true, oscillations will be detected by checking the frequency of change in ang_vel direction
      bool is_oscillating_ = false; //if true, this will trigger oscillation handling
      std::vector<std::vector<double>> av_oscillation_data_vector_; //vector to collect oscillation data and time
	}; 
}
#endif // MAXL_PLANNER_OSCILLATION_H