// Auto-generated. Do not edit!

// (in-package mw_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Route = require('./Route.js');
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class Task {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.id = null;
      this.route = null;
      this.task_goal = null;
      this.duration = null;
      this.end_behaviour = null;
      this.type = null;
      this.status = null;
    }
    else {
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = 0;
      }
      if (initObj.hasOwnProperty('route')) {
        this.route = initObj.route
      }
      else {
        this.route = new Route();
      }
      if (initObj.hasOwnProperty('task_goal')) {
        this.task_goal = initObj.task_goal
      }
      else {
        this.task_goal = new geometry_msgs.msg.Pose();
      }
      if (initObj.hasOwnProperty('duration')) {
        this.duration = initObj.duration
      }
      else {
        this.duration = 0.0;
      }
      if (initObj.hasOwnProperty('end_behaviour')) {
        this.end_behaviour = initObj.end_behaviour
      }
      else {
        this.end_behaviour = 0.0;
      }
      if (initObj.hasOwnProperty('type')) {
        this.type = initObj.type
      }
      else {
        this.type = 0;
      }
      if (initObj.hasOwnProperty('status')) {
        this.status = initObj.status
      }
      else {
        this.status = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Task
    // Serialize message field [id]
    bufferOffset = _serializer.uint32(obj.id, buffer, bufferOffset);
    // Serialize message field [route]
    bufferOffset = Route.serialize(obj.route, buffer, bufferOffset);
    // Serialize message field [task_goal]
    bufferOffset = geometry_msgs.msg.Pose.serialize(obj.task_goal, buffer, bufferOffset);
    // Serialize message field [duration]
    bufferOffset = _serializer.float32(obj.duration, buffer, bufferOffset);
    // Serialize message field [end_behaviour]
    bufferOffset = _serializer.float32(obj.end_behaviour, buffer, bufferOffset);
    // Serialize message field [type]
    bufferOffset = _serializer.uint8(obj.type, buffer, bufferOffset);
    // Serialize message field [status]
    bufferOffset = _serializer.uint8(obj.status, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Task
    let len;
    let data = new Task(null);
    // Deserialize message field [id]
    data.id = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [route]
    data.route = Route.deserialize(buffer, bufferOffset);
    // Deserialize message field [task_goal]
    data.task_goal = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset);
    // Deserialize message field [duration]
    data.duration = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [end_behaviour]
    data.end_behaviour = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [type]
    data.type = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [status]
    data.status = _deserializer.uint8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += Route.getMessageSize(object.route);
    return length + 70;
  }

  static datatype() {
    // Returns string type for a message object
    return 'mw_msgs/Task';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '4d016d3cafcc60f633b0e31dcaeb9372';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Unique ID for each task
    uint32 id
    
    # task_goal field when type is GTG
    mw_msgs/Route route
    geometry_msgs/Pose task_goal
    
    # Duration (in seconds) to run this task (when type is not ROUTE)
    float32 duration
    
    # End behaviour, ie, time to wait after this task ends and before starting the next task
    float32 end_behaviour
    
    # Enumeration for different types
    uint8 GTG=0
    uint8 WAIT=1
    
    # Type of task
    uint8 type
    
    
    # Enumeration for different task states
    uint8 NOT_STARTED=0
    uint8 WIP=1
    uint8 COMPLETED=2
    
    # Task status
    uint8 status
    
    
    ================================================================================
    MSG: mw_msgs/Route
    # Unique ID for each different route
    uint32 id
    
    # Header
    std_msgs/Header header
    
    # Array of waypoints
    geometry_msgs/PoseStamped[] waypoints
    
    # Route status
    uint8 status
    
    # Enumeration for different route states
    uint8 NOT_STARTED=0
    uint8 WIP=1
    uint8 COMPLETED=2
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/PoseStamped
    # A Pose with reference coordinate frame and timestamp
    Header header
    Pose pose
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Task(null);
    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = 0
    }

    if (msg.route !== undefined) {
      resolved.route = Route.Resolve(msg.route)
    }
    else {
      resolved.route = new Route()
    }

    if (msg.task_goal !== undefined) {
      resolved.task_goal = geometry_msgs.msg.Pose.Resolve(msg.task_goal)
    }
    else {
      resolved.task_goal = new geometry_msgs.msg.Pose()
    }

    if (msg.duration !== undefined) {
      resolved.duration = msg.duration;
    }
    else {
      resolved.duration = 0.0
    }

    if (msg.end_behaviour !== undefined) {
      resolved.end_behaviour = msg.end_behaviour;
    }
    else {
      resolved.end_behaviour = 0.0
    }

    if (msg.type !== undefined) {
      resolved.type = msg.type;
    }
    else {
      resolved.type = 0
    }

    if (msg.status !== undefined) {
      resolved.status = msg.status;
    }
    else {
      resolved.status = 0
    }

    return resolved;
    }
};

// Constants for message
Task.Constants = {
  GTG: 0,
  WAIT: 1,
  NOT_STARTED: 0,
  WIP: 1,
  COMPLETED: 2,
}

module.exports = Task;
