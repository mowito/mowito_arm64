// Auto-generated. Do not edit!

// (in-package mw_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

let Duty = require('../msg/Duty.js');

//-----------------------------------------------------------

class LoadDutyFromFileRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.file_name = null;
    }
    else {
      if (initObj.hasOwnProperty('file_name')) {
        this.file_name = initObj.file_name
      }
      else {
        this.file_name = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LoadDutyFromFileRequest
    // Serialize message field [file_name]
    bufferOffset = _serializer.string(obj.file_name, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LoadDutyFromFileRequest
    let len;
    let data = new LoadDutyFromFileRequest(null);
    // Deserialize message field [file_name]
    data.file_name = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.file_name.length;
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'mw_msgs/LoadDutyFromFileRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '2415261c9605b9f38867ffbbe495fc04';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string file_name
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LoadDutyFromFileRequest(null);
    if (msg.file_name !== undefined) {
      resolved.file_name = msg.file_name;
    }
    else {
      resolved.file_name = ''
    }

    return resolved;
    }
};

class LoadDutyFromFileResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.duty = null;
    }
    else {
      if (initObj.hasOwnProperty('duty')) {
        this.duty = initObj.duty
      }
      else {
        this.duty = new Duty();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LoadDutyFromFileResponse
    // Serialize message field [duty]
    bufferOffset = Duty.serialize(obj.duty, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LoadDutyFromFileResponse
    let len;
    let data = new LoadDutyFromFileResponse(null);
    // Deserialize message field [duty]
    data.duty = Duty.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += Duty.getMessageSize(object.duty);
    return length;
  }

  static datatype() {
    // Returns string type for a service object
    return 'mw_msgs/LoadDutyFromFileResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '730272cc5e01feca01f4ecc36a4ce232';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    mw_msgs/Duty duty
    
    ================================================================================
    MSG: mw_msgs/Duty
    # Unique ID for each duty
    uint32 id
    
    # Total number of tasks
    uint64 total_tasks
    
    # List of tasks
    mw_msgs/Task[] tasks
    
    # Is loop enabled
    bool loop_enabled
    ================================================================================
    MSG: mw_msgs/Task
    # Unique ID for each task
    uint32 id
    
    # task_goal field when type is GTG
    mw_msgs/Route route
    geometry_msgs/Pose task_goal
    
    # Duration (in seconds) to run this task (when type is not ROUTE)
    float32 duration
    
    # End behaviour, ie, time to wait after this task ends and before starting the next task
    float32 end_behaviour
    
    # Enumeration for different types
    uint8 GTG=0
    uint8 WAIT=1
    
    # Type of task
    uint8 type
    
    
    # Enumeration for different task states
    uint8 NOT_STARTED=0
    uint8 WIP=1
    uint8 COMPLETED=2
    
    # Task status
    uint8 status
    
    
    ================================================================================
    MSG: mw_msgs/Route
    # Unique ID for each different route
    uint32 id
    
    # Header
    std_msgs/Header header
    
    # Array of waypoints
    geometry_msgs/PoseStamped[] waypoints
    
    # Route status
    uint8 status
    
    # Enumeration for different route states
    uint8 NOT_STARTED=0
    uint8 WIP=1
    uint8 COMPLETED=2
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/PoseStamped
    # A Pose with reference coordinate frame and timestamp
    Header header
    Pose pose
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LoadDutyFromFileResponse(null);
    if (msg.duty !== undefined) {
      resolved.duty = Duty.Resolve(msg.duty)
    }
    else {
      resolved.duty = new Duty()
    }

    return resolved;
    }
};

module.exports = {
  Request: LoadDutyFromFileRequest,
  Response: LoadDutyFromFileResponse,
  md5sum() { return '8a0e3728d8fac11c6396778f2abb8620'; },
  datatype() { return 'mw_msgs/LoadDutyFromFile'; }
};
