
"use strict";

let GetCircumscribedRadius = require('./GetCircumscribedRadius.js')
let LoadTaskFromFile = require('./LoadTaskFromFile.js')
let GetRouteStatus = require('./GetRouteStatus.js')
let SetRoute = require('./SetRoute.js')
let GetSbplPlan = require('./GetSbplPlan.js')
let GetPlan = require('./GetPlan.js')
let FleetStatus = require('./FleetStatus.js')
let ComputeCircumscribedCost = require('./ComputeCircumscribedCost.js')
let SetString = require('./SetString.js')
let SetTask = require('./SetTask.js')
let LoadRouteFromFile = require('./LoadRouteFromFile.js')
let GetString = require('./GetString.js')
let GetRoute = require('./GetRoute.js')
let SetPlan = require('./SetPlan.js')
let GetTask = require('./GetTask.js')
let SetCost = require('./SetCost.js')
let SetRobotFootprint = require('./SetRobotFootprint.js')
let GetPose = require('./GetPose.js')
let SetDuty = require('./SetDuty.js')
let LoadDutyFromFile = require('./LoadDutyFromFile.js')
let RobotInfo = require('./RobotInfo.js')
let GetDuty = require('./GetDuty.js')
let SetNodeState = require('./SetNodeState.js')
let SetManual = require('./SetManual.js')
let SetMode = require('./SetMode.js')
let GetTaskStatus = require('./GetTaskStatus.js')
let GetDouble = require('./GetDouble.js')
let ChangeMprims = require('./ChangeMprims.js')

module.exports = {
  GetCircumscribedRadius: GetCircumscribedRadius,
  LoadTaskFromFile: LoadTaskFromFile,
  GetRouteStatus: GetRouteStatus,
  SetRoute: SetRoute,
  GetSbplPlan: GetSbplPlan,
  GetPlan: GetPlan,
  FleetStatus: FleetStatus,
  ComputeCircumscribedCost: ComputeCircumscribedCost,
  SetString: SetString,
  SetTask: SetTask,
  LoadRouteFromFile: LoadRouteFromFile,
  GetString: GetString,
  GetRoute: GetRoute,
  SetPlan: SetPlan,
  GetTask: GetTask,
  SetCost: SetCost,
  SetRobotFootprint: SetRobotFootprint,
  GetPose: GetPose,
  SetDuty: SetDuty,
  LoadDutyFromFile: LoadDutyFromFile,
  RobotInfo: RobotInfo,
  GetDuty: GetDuty,
  SetNodeState: SetNodeState,
  SetManual: SetManual,
  SetMode: SetMode,
  GetTaskStatus: GetTaskStatus,
  GetDouble: GetDouble,
  ChangeMprims: ChangeMprims,
};
