// Auto-generated. Do not edit!

// (in-package mw_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

let RobotStatus = require('../msg/RobotStatus.js');

//-----------------------------------------------------------

class FleetStatusRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
    }
    else {
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FleetStatusRequest
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FleetStatusRequest
    let len;
    let data = new FleetStatusRequest(null);
    return data;
  }

  static getMessageSize(object) {
    return 0;
  }

  static datatype() {
    // Returns string type for a service object
    return 'mw_msgs/FleetStatusRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd41d8cd98f00b204e9800998ecf8427e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FleetStatusRequest(null);
    return resolved;
    }
};

class FleetStatusResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.fleet_status = null;
    }
    else {
      if (initObj.hasOwnProperty('fleet_status')) {
        this.fleet_status = initObj.fleet_status
      }
      else {
        this.fleet_status = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FleetStatusResponse
    // Serialize message field [fleet_status]
    // Serialize the length for message field [fleet_status]
    bufferOffset = _serializer.uint32(obj.fleet_status.length, buffer, bufferOffset);
    obj.fleet_status.forEach((val) => {
      bufferOffset = RobotStatus.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FleetStatusResponse
    let len;
    let data = new FleetStatusResponse(null);
    // Deserialize message field [fleet_status]
    // Deserialize array length for message field [fleet_status]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.fleet_status = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.fleet_status[i] = RobotStatus.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.fleet_status.forEach((val) => {
      length += RobotStatus.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'mw_msgs/FleetStatusResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c95c21b641de9fa4c4335d8373a9cd64';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    mw_msgs/RobotStatus[] fleet_status
    
    ================================================================================
    MSG: mw_msgs/RobotStatus
    # robot status for UI
    
    # robot id
    string robot_id
    
    # robot ip
    string robot_ip
    
    # robot type
    string robot_type
    
    # 0 means no duty set / any positive integer represents a duty
    uint32 current_duty_id
    
    # if no duty set this is gibberish otherwise it represents the task id currently running
    uint32 current_task_id
    
    # if no duty set this is gibberish otherwise it represents type of current task 0 == route 1 == attachement task
    uint8 task_type
    
    # robot mission status
    mw_msgs/mission_status robot_mission_status
    
    # robot battery state
    sensor_msgs/BatteryState robot_battery_state
    
    # 0 == all is well any positive int means there is an issue for now just display the number
    int32 error_code
    
    
    ================================================================================
    MSG: mw_msgs/mission_status
    # status indicating the navigation mode of executive (AUTONOMY/MANUAL/SAFETELEOP)
    string nav_mode
    
    # status indicating machine state (PLANNING/CONTROLLING/RECOVERING/WAITING/NA) (NA state is when mission nav_mode is working in Manual or Safe telop mode)
    string autonomy_state
    
    # status indicating name of the controller type being used
    string controller_type
    
    # status indicating name of the global planner type being used
    string global_planner_type
    
    # status indicating current position and orientation of the robot
    geometry_msgs/PoseStamped current_pose
    
    # status indicating the current goal being pursued by the robot 
    geometry_msgs/PoseStamped current_goal
    ================================================================================
    MSG: geometry_msgs/PoseStamped
    # A Pose with reference coordinate frame and timestamp
    Header header
    Pose pose
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    ================================================================================
    MSG: sensor_msgs/BatteryState
    
    # Constants are chosen to match the enums in the linux kernel
    # defined in include/linux/power_supply.h as of version 3.7
    # The one difference is for style reasons the constants are
    # all uppercase not mixed case.
    
    # Power supply status constants
    uint8 POWER_SUPPLY_STATUS_UNKNOWN = 0
    uint8 POWER_SUPPLY_STATUS_CHARGING = 1
    uint8 POWER_SUPPLY_STATUS_DISCHARGING = 2
    uint8 POWER_SUPPLY_STATUS_NOT_CHARGING = 3
    uint8 POWER_SUPPLY_STATUS_FULL = 4
    
    # Power supply health constants
    uint8 POWER_SUPPLY_HEALTH_UNKNOWN = 0
    uint8 POWER_SUPPLY_HEALTH_GOOD = 1
    uint8 POWER_SUPPLY_HEALTH_OVERHEAT = 2
    uint8 POWER_SUPPLY_HEALTH_DEAD = 3
    uint8 POWER_SUPPLY_HEALTH_OVERVOLTAGE = 4
    uint8 POWER_SUPPLY_HEALTH_UNSPEC_FAILURE = 5
    uint8 POWER_SUPPLY_HEALTH_COLD = 6
    uint8 POWER_SUPPLY_HEALTH_WATCHDOG_TIMER_EXPIRE = 7
    uint8 POWER_SUPPLY_HEALTH_SAFETY_TIMER_EXPIRE = 8
    
    # Power supply technology (chemistry) constants
    uint8 POWER_SUPPLY_TECHNOLOGY_UNKNOWN = 0
    uint8 POWER_SUPPLY_TECHNOLOGY_NIMH = 1
    uint8 POWER_SUPPLY_TECHNOLOGY_LION = 2
    uint8 POWER_SUPPLY_TECHNOLOGY_LIPO = 3
    uint8 POWER_SUPPLY_TECHNOLOGY_LIFE = 4
    uint8 POWER_SUPPLY_TECHNOLOGY_NICD = 5
    uint8 POWER_SUPPLY_TECHNOLOGY_LIMN = 6
    
    Header  header
    float32 voltage          # Voltage in Volts (Mandatory)
    float32 current          # Negative when discharging (A)  (If unmeasured NaN)
    float32 charge           # Current charge in Ah  (If unmeasured NaN)
    float32 capacity         # Capacity in Ah (last full capacity)  (If unmeasured NaN)
    float32 design_capacity  # Capacity in Ah (design capacity)  (If unmeasured NaN)
    float32 percentage       # Charge percentage on 0 to 1 range  (If unmeasured NaN)
    uint8   power_supply_status     # The charging status as reported. Values defined above
    uint8   power_supply_health     # The battery health metric. Values defined above
    uint8   power_supply_technology # The battery chemistry. Values defined above
    bool    present          # True if the battery is present
    
    float32[] cell_voltage   # An array of individual cell voltages for each cell in the pack
                             # If individual voltages unknown but number of cells known set each to NaN
    string location          # The location into which the battery is inserted. (slot number or plug)
    string serial_number     # The best approximation of the battery serial number
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FleetStatusResponse(null);
    if (msg.fleet_status !== undefined) {
      resolved.fleet_status = new Array(msg.fleet_status.length);
      for (let i = 0; i < resolved.fleet_status.length; ++i) {
        resolved.fleet_status[i] = RobotStatus.Resolve(msg.fleet_status[i]);
      }
    }
    else {
      resolved.fleet_status = []
    }

    return resolved;
    }
};

module.exports = {
  Request: FleetStatusRequest,
  Response: FleetStatusResponse,
  md5sum() { return 'c95c21b641de9fa4c4335d8373a9cd64'; },
  datatype() { return 'mw_msgs/FleetStatus'; }
};
